package app.spendsense.tracker;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.regex.Pattern;

/**
 * Optional NotificationListenerService that detects transaction push notifications
 * from bKash, Nagad, Rocket, and bank apps and routes them into SpendSense's draft queue.
 */
public class SpendSenseNotificationListener extends NotificationListenerService {
    private static final Pattern FIN_PATTERN =
        Pattern.compile("(bKash|Nagad|Rocket|DBBL|Tk\.?|BDT|TrxID|TxnID)", Pattern.CASE_INSENSITIVE);

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;
        CharSequence title = extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        String combined = ((title != null ? title.toString() + ": " : "") + (text != null ? text.toString() : "")).trim();
        if (combined.length() > 12 && FIN_PATTERN.matcher(combined).find()) {
            Intent forward = new Intent(MainActivity.ACTION_INCOMING_FIN_SMS);
            forward.setPackage(getPackageName());
            forward.putExtra("sms_body", combined);
            sendBroadcast(forward);
        }
    }
}
