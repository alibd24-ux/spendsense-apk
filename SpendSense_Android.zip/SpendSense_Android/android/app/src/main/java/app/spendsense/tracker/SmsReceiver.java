package app.spendsense.tracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.regex.Pattern;

/**
 * Listens for incoming mobile-banking SMS messages (bKash, Nagad, Rocket, Banks)
 * and forwards matching drafts to MainActivity for explicit user confirmation.
 */
public class SmsReceiver extends BroadcastReceiver {
    private static final Pattern FIN_PATTERN =
        Pattern.compile("(bKash|Nagad|Rocket|DBBL|Tk\.?|BDT|TrxID|TxnID)", Pattern.CASE_INSENSITIVE);

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            return;
        }
        SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (messages == null || messages.length == 0) return;

        StringBuilder fullBody = new StringBuilder();
        for (SmsMessage msg : messages) {
            if (msg != null && msg.getMessageBody() != null) {
                fullBody.append(msg.getMessageBody());
            }
        }
        String text = fullBody.toString().trim();
        if (FIN_PATTERN.matcher(text).find()) {
            Intent forward = new Intent(MainActivity.ACTION_INCOMING_FIN_SMS);
            forward.setPackage(context.getPackageName());
            forward.putExtra("sms_body", text);
            context.sendBroadcast(forward);
        }
    }
}
