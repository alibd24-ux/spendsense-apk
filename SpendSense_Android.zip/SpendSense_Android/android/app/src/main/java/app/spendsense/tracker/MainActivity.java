package app.spendsense.tracker;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.Pattern;

/**
 * SpendSense MainActivity — Hosts the exact SpendSense UI/UX in a hardware-accelerated
 * Android WebView and exposes native Android platform capabilities via window.AndroidBridge:
 * - Native SQLite / SharedPreferences persistent storage backup mirror
 * - Native Haptics (Vibrator)
 * - Native Voice Input (SpeechRecognizer for en-US & bn-BD)
 * - Native SMS inbox reader & real-time BroadcastReceiver for bKash/Nagad/Rocket/Banks
 * - Native FileChooser for Receipt Photos & JSON Backup Restore
 * - Native PDF / CSV / JSON file saving & system Share Sheet via FileProvider
 */
public class MainActivity extends AppCompatActivity {
    public static final String ACTION_INCOMING_FIN_SMS = "app.spendsense.tracker.INCOMING_FIN_SMS";
    private static final String PREFS_NAME = "spendsense_native_store";
    private static final String KEY_BACKUP_JSON = "db_backup_json";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                String dataString = result.getData().getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        });

    private final ActivityResultLauncher<Intent> voiceLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                ArrayList<String> matches = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (matches != null && !matches.isEmpty()) {
                    String text = matches.get(0).replace("'", "\\'");
                    webView.post(() -> webView.evaluateJavascript("window.onAndroidVoiceResult && window.onAndroidVoiceResult('" + text + "')", null));
                    return;
                }
            }
            webView.post(() -> webView.evaluateJavascript("window.onAndroidVoiceResult && window.onAndroidVoiceResult('')", null));
        });

    private final BroadcastReceiver smsEventReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_INCOMING_FIN_SMS.equals(intent.getAction())) {
                String body = intent.getStringExtra("sms_body");
                if (body != null && webView != null) {
                    String escaped = body.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
                    webView.post(() -> webView.evaluateJavascript("window.onAndroidIncomingSms && window.onAndroidIncomingSms('" + escaped + "')", null));
                }
            }
        }
    };

    @SuppressLint({"SetJavaScriptEnabled", "UnspecifiedRegisterReceiverFlag"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv, ValueCallback<Uri[]> filePathCb, FileChooserParams fileChooserParams) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCb;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.setBackgroundColor(Color.BLACK);
        webView.loadUrl("file:///android_asset/public/index.html");

        IntentFilter filter = new IntentFilter(ACTION_INCOMING_FIN_SMS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(smsEventReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(smsEventReceiver, filter);
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(window.handleAndroidBack ? window.handleAndroidBack() : 'exit')",
                    result -> {
                        if (""exit"".equals(result) || "null".equals(result)) {
                            finish();
                        }
                    }
                );
            }
        });
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(smsEventReceiver);
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void vibrate(int durationMs) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(Math.max(5, durationMs), VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(Math.max(5, durationMs));
                    }
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void setStatusBarTheme(String mode) {
            runOnUiThread(() -> {
                boolean dark = !"light".equalsIgnoreCase(mode);
                int bg = dark ? Color.parseColor("#000000") : Color.parseColor("#F5F6FA");
                getWindow().setStatusBarColor(bg);
                getWindow().setNavigationBarColor(bg);
            });
        }

        @JavascriptInterface
        public void saveBackupJson(String json) {
            try {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                prefs.edit().putString(KEY_BACKUP_JSON, json).apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String loadBackupJson() {
            try {
                SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                return prefs.getString(KEY_BACKUP_JSON, "");
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void startVoiceRecognition(String lang) {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang != null ? lang : "en-US");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak expense (e.g. Lunch 250 taka via bKash)");
                    voiceLauncher.launch(intent);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void shareText(String text) {
            runOnUiThread(() -> {
                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, text);
                sendIntent.setType("text/plain");
                startActivity(Intent.createChooser(sendIntent, "Share via"));
            });
        }

        @JavascriptInterface
        public void saveAndShareTextFile(String fileName, String content, String mimeType) {
            runOnUiThread(() -> {
                try {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = new File(dir, fileName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(content.getBytes(StandardCharsets.UTF_8));
                    }
                    shareFileUri(outFile, mimeType != null ? mimeType : "text/plain");
                } catch (Exception e) {
                    try {
                        File cacheFile = new File(getCacheDir(), fileName);
                        try (FileOutputStream fos = new FileOutputStream(cacheFile)) {
                            fos.write(content.getBytes(StandardCharsets.UTF_8));
                        }
                        shareFileUri(cacheFile, mimeType != null ? mimeType : "text/plain");
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void saveAndShareBase64File(String fileName, String base64Data, String mimeType, boolean shareImmediately) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    File outFile = new File(dir, fileName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(bytes);
                    }
                    if (shareImmediately) {
                        shareFileUri(outFile, mimeType != null ? mimeType : "application/pdf");
                    }
                } catch (Exception e) {
                    try {
                        byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                        File cacheFile = new File(getCacheDir(), fileName);
                        try (FileOutputStream fos = new FileOutputStream(cacheFile)) {
                            fos.write(bytes);
                        }
                        shareFileUri(cacheFile, mimeType != null ? mimeType : "application/pdf");
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public String getRecentFinancialSms() {
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, 101);
                return "";
            }
            StringBuilder sb = new StringBuilder();
            Pattern finPattern = Pattern.compile("(bKash|Nagad|Rocket|DBBL|Tk\.?|BDT|TrxID|TxnID)", Pattern.CASE_INSENSITIVE);
            try (Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"body", "date"}, null, null, "date DESC LIMIT 60")) {
                if (cursor != null) {
                    int count = 0;
                    while (cursor.moveToNext() && count < 15) {
                        String body = cursor.getString(0);
                        if (body != null && finPattern.matcher(body).find()) {
                            if (sb.length() > 0) sb.append("\n\n");
                            sb.append(body.trim());
                            count++;
                        }
                    }
                }
            } catch (Exception ignored) {}
            return sb.toString();
        }

        private void shareFileUri(File file, String mimeType) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType(mimeType);
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, "Share " + file.getName()));
            } catch (Exception ignored) {}
        }
    }
}
