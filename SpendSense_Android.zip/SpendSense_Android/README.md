# SpendSense — AI-Powered Expense Tracker (Full Functional Android App)

This project converts the uploaded **SpendSense** Next.js + PostgreSQL application into a **100% functional, offline-first Native Android application** (`app.spendsense.tracker`) with **zero UI or UX changes**.

---

## What Changed Under the Hood (While Keeping 100% Identical UI & UX)

1. **Zero UI/UX Changes**:
   - Preserves the exact AMOLED-neon (`#000000`, `#00F5FF`, `#FF2BD6`, `#B6FF00`) and clean Light (`#F5F6FA`) themes, Space Grotesk + Hind Siliguri typography, bottom navigation bar, glowing FAB, custom SVG charts (Donut, Bar/Line Trend, Progress Ring, Calendar Heatmap, Animated Neon Flame), and all 14 screens.
2. **Serverless Offline-First Database Engine**:
   - Replaced the PostgreSQL (`pg` + `drizzle-orm`) backend and Next.js `"use server"` actions with an instant client-side database engine (`localStorage` + Native Android `SharedPreferences` backup mirror) that auto-seeds the exact same 120-day realistic dataset, budgets, split groups, loans, recurring rules, and savings goals on first launch.
3. **Native Android Platform Integration (`window.AndroidBridge`)**:
   - **`MainActivity.java`**: Hardware-accelerated `WebView` with native `@JavascriptInterface` (`AndroidBridge`), hardware Back button navigation (closes active modal → returns to More/Home → exits app), file picker for receipt photos and JSON restore, and status/navigation bar color syncing.
   - **`SmsReceiver.java` & `SpendSenseNotificationListener.java`**: Real-time Android `BroadcastReceiver` (`SMS_RECEIVED`) and `NotificationListenerService` + inbox scanner (`content://sms/inbox`) for bKash, Nagad, Rocket, and bank messages with TrxID deduplication.
   - **Native Speech Recognition**: Connects the Home quick-add microphone button to Android's native `RecognizerIntent` (`en-US` and `bn-BD`) with Web Speech API fallback.
   - **Native PDF, CSV & JSON Export/Share**: Saves generated PDF reports (`jsPDF`), CSV exports, and JSON backups directly to the device's `Downloads` folder and triggers the native Android Share Sheet via `androidx.core.content.FileProvider`.

---

## How to Build the APK

### Option 1: Android Studio (Recommended)
1. Extract `SpendSense_Android_Project.zip`.
2. Open **Android Studio** → **Open** → select the `android` folder inside the extracted project.
3. Wait for Gradle Sync to complete.
4. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Your installable APK will be generated at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

### Option 2: 1-Click Cloud Build via GitHub Actions (No Local Setup Needed)
1. Push this extracted folder to a GitHub repository.
2. Open the **Actions** tab in GitHub and run the **Build SpendSense Android APK** workflow.
3. Download the compiled `SpendSense-debug-apk` artifact directly to your phone.
